# Problem 5
Bookmark this page
## Problem 5
4.0/4.0 points (graded)  
Which graph, choosing a specific day (Jan 10) or calculating the yearly average, indicates that almost none of the data variation is learned by our model?


choosing a specific day correct

Which graph, choosing a specific day (Jan 10) or calculating the yearly average, supports more the claim that global warming is leading to an increase in temperature?


calculating the yearly average correct
