# Problem 7
Bookmark this page
## Problem 7-1
0.0/3.0 points (graded)  
Answer the next questions on machine learning, related to the following data. Consider the following 6 people who are either happy or unhappy and the data we know on them:


|  |   Person 1   | Person 2  | Person 3 | Person 4| Person 5 | Person 6|
| - |:-------------:|:-----:|:-:|:-:|:-:|:-:|
| **Happy/Unhappy** |happy|happy|happy|unhappy|unhappy|unhappy|
|**Income (dollars)**     |10k|30k|90k|100k|120k|60k|
|**Distance from North Pole (miles)**|4k|10k|5k|1k|1k|6k|
|**Continents Visited**|Europe|Europe|Europe|Europe|Europe|Europe|
|**Age**|25|19|26|57|60|40|

Using the Manhattan distance and looking only at "Income" and "Distance from North Pole", which two people are closest and farthest?

closest: Person 3 and Person 4 ||| farthest: Person 5 and Person 6 incorrect


## Problem 7-2
3.0/3.0 points (graded)  
If we were to cluster the people, the inclusion/exclusion of which feature would never impact the final clusters?

Continents Visited correct
