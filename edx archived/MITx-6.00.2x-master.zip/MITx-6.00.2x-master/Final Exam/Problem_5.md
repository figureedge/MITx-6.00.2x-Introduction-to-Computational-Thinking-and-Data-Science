# Problem 5
Bookmark this page
## Problem 5
12.0/12.0 points (graded)  
K-means is a greedy algorithm, meaning it looks for local minimum when choosing points closest to the centroid. For each dataset illustrated below, will k-means, as shown in lecture, using Euclidean distance as the metric be able to find clusters that match the dataset patterns?

![](https://d37djvu3ytnwxt.cloudfront.net/assets/courseware/v1/e8942b1bf2f1371214ee944484a73f9c/asset-v1:MITx+6.00.2x_7+1T2017+type@asset+block/k7.png)  
Dataset 1

No correct

![](https://d37djvu3ytnwxt.cloudfront.net/assets/courseware/v1/932109216b138fbbe8de2bcacdbea18f/asset-v1:MITx+6.00.2x_7+1T2017+type@asset+block/k2.png)  
Dataset 2

Yes correct

![](https://d37djvu3ytnwxt.cloudfront.net/assets/courseware/v1/c89f86964407d5c30b70b231be859a5f/asset-v1:MITx+6.00.2x_7+1T2017+type@asset+block/k3.png)  
Dataset 3

No correct

![](https://d37djvu3ytnwxt.cloudfront.net/assets/courseware/v1/630cfabcda91f8e731a3edf977f48346/asset-v1:MITx+6.00.2x_7+1T2017+type@asset+block/k4.png)  
Dataset 4

No correct

![](https://d37djvu3ytnwxt.cloudfront.net/assets/courseware/v1/8091466c27c09d43ff1fe2346a76ac06/asset-v1:MITx+6.00.2x_7+1T2017+type@asset+block/k5.png)  
Dataset 5

Yes correct

![](https://d37djvu3ytnwxt.cloudfront.net/assets/courseware/v1/b9f9f62fc86582a8bf86fb1e23fe8477/asset-v1:MITx+6.00.2x_7+1T2017+type@asset+block/k6.png)  
Dataset 6

No correct
