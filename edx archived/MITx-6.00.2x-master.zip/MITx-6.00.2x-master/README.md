# MITx-6.00.2x
Coding exercises, Problem Sets, and lecture code for MITx: 6.00.2x Introduction to Computational Thinking and Data Science, EdX, March-May 2017

All code in this course uses Python 3.x.
